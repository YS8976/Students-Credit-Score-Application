from students_credit_app import db, create_app
from students_credit_app.models import User
from werkzeug.security import generate_password_hash  

app = create_app()  # Initialize Flask app

with app.app_context():  # Ensure we are inside the application context
    new_user = User(
        full_name="John Doe",
        role="Student",
        course="Computer Science",
        year=4,
        admission_year=2021,
        end_year=2025,
        student_id="CS12345",
        email="johndoe@bkbck",
        password=generate_password_hash("password123", method='pbkdf2:sha256'),
        credit_points=0
    )

    db.session.add(new_user)
    db.session.commit()

    print("User added successfully!")
