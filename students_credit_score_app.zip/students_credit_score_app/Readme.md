flask --app students_credit_app run --debug

for hosting on phone locally :-  flask run --host=0.0.0.0 --port=5000