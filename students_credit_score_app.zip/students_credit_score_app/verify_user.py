from students_credit_app import db
from students_credit_app.models import User

user = User.query.filter_by(email="johndoe@bkbck").first()
print(f"Stored password: {user.password}")  # Should be a long hashed string
