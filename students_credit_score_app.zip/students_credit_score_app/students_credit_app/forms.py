from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, IntegerField, FileField, TextAreaField
from wtforms.validators import DataRequired, Length, EqualTo, Email, NumberRange


# User Registration Form
class RegistrationForm(FlaskForm):
    full_name = StringField('Full Name', validators=[DataRequired(), Length(min=3, max=50)])
    role = SelectField('Role', choices=[('student', 'Student'), ('teacher', 'Teacher')], validators=[DataRequired()])
    course = SelectField('Select Course', choices=[
        ('computer_science', 'Computer Science'),
        ('electronics', 'Electronics'),
        ('mechanical', 'Mechanical'),
        ('civil', 'Civil'),
        ('it', 'Information Technology')
    ], validators=[DataRequired()])
    year = SelectField('Year', choices=[('FY', 'FY'), ('SY', 'SY'), ('TY', 'TY')], validators=[DataRequired()])
    admission_year = IntegerField('Admission Year', validators=[DataRequired(), NumberRange(min=2000, max=2100)])
    end_year = IntegerField('End Year', validators=[DataRequired(), NumberRange(min=2000, max=2100)])
    student_id = IntegerField('Student ID', validators=[DataRequired()])
    email_username = StringField('Email Username', validators=[DataRequired(), Length(min=3, max=20)])
    password = PasswordField('Create Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')
# User Login Form
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

# Certificate Upload Form
class CertificateForm(FlaskForm):
    certificate_name = StringField('Certificate Name', validators=[DataRequired()])
    certificate_file = FileField('Upload Certificate', validators=[DataRequired()])
    credit_points = IntegerField('Credit Points', validators=[DataRequired(), NumberRange(min=1, max=100)])
    submit = SubmitField('Upload')

# Assign In-College Task Form
class TaskForm(FlaskForm):
    task_name = StringField('Task Name', validators=[DataRequired()])
    description = TextAreaField('Task Description', validators=[DataRequired(), Length(min=10)])
    credit_points = IntegerField('Credit Points', validators=[DataRequired(), NumberRange(min=1, max=50)])
    submit = SubmitField('Assign Task')
