import os

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", os.urandom(24))  # Uses env variable or generates a random key
    FIREBASE_CONFIG = {
        "apiKey": "AIzaSyC5E9rLx2yfA_wIpDBPsf60bTztaaVJHgw",
        "authDomain": "creditscoreapp-1d5dc.firebaseapp.com",
        "projectId": "creditscoreapp-1d5dc",
        "storageBucket": "creditscoreapp-1d5dc.appspot.com",
        "messagingSenderId": "1073791004936",
        "appId": "1:1073791004936:web:504301c7517f658fe57cbd",
        "databaseURL": ""  # If you're using Firestore, leave this empty
    }