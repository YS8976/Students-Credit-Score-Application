from flask import Flask
import os
from firebase_config import auth, db  # Import Firebase authentication & Firestore

def create_app():
    app = Flask(__name__)

    # Secret Key (Change this in production)
    app.config['SECRET_KEY'] = '2af1222dd2956b4e840d55d3fc185169c89a1f46eda8d4755b5b3c03ba9dae27'  # Change to a secure key in production

    # Initialize Routes
    from students_credit_app.routes import init_routes
    init_routes(app)

    return app
