from students_credit_app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

# User Model


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(50), nullable=False)
    role = db.Column(db.String(10), nullable=False)  # student or teacher
    course = db.Column(db.String(50), nullable=False)
    year = db.Column(db.String(10), nullable=False)  # FY, SY, TY
    admission_year = db.Column(db.Integer, nullable=False)
    end_year = db.Column(db.Integer, nullable=False)
    student_id = db.Column(db.Integer, unique=True, nullable=False)
    email = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)  # 🔹 Increased length for hash storage
    credit_points = db.Column(db.Integer, default=0)

    def set_password(self, password):
        """Hashes the password and stores it securely."""
        self.password = generate_password_hash(password)

    def check_password(self, password):
        """Checks the hashed password."""
        return check_password_hash(self.password, password)

    def __repr__(self):
        return f"User('{self.full_name}', '{self.email}', '{self.role}')"

# Barcode Certificate Model
class Certificate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    certificate_name = db.Column(db.String(255), nullable=False)
    certificate_file = db.Column(db.String(255), nullable=False)  # File path or URL
    credit_points = db.Column(db.Integer, nullable=False)

    user = db.relationship('User', backref=db.backref('certificates', lazy=True))

# Student Information Model
class StudentInfo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    year_of_study = db.Column(db.Integer, nullable=False)
    class_division = db.Column(db.String(50), nullable=False)
    start_year = db.Column(db.Integer, nullable=False)
    passing_year = db.Column(db.Integer, nullable=False)

    user = db.relationship('User', backref=db.backref('student_info', uselist=False))

# Leaderboard Model (to rank students)
class Leaderboard(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    total_points = db.Column(db.Integer, default=0)

    user = db.relationship('User', backref=db.backref('leaderboard_entry', uselist=False))

# In-College Task Model
class InCollegeTask(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    task_name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    assigned_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    assigned_to = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    credit_points = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(50), default='Pending')  # Pending, Accepted, Completed

    assigner = db.relationship('User', foreign_keys=[assigned_by], backref=db.backref('tasks_created', lazy=True))
    assignee = db.relationship('User', foreign_keys=[assigned_to], backref=db.backref('tasks_assigned', lazy=True), uselist=False)

# Function to Create Database Tables
def init_db():
    with db.session.begin():
        db.create_all()
