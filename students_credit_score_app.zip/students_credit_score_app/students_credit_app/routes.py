from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify,send_file
import io
import sys
import os
import json
from datetime import timedelta, datetime
import traceback
import time
import urllib.parse
from flask_login import login_required, current_user
from firebase_admin import credentials, firestore, storage
from flask import Flask, render_template, session, redirect, url_for, flash
from firebase_config import login_user
from firebase_config import auth, db  # Firebase modules
import firebase_admin
from flask_session import Session
from flask_login import LoginManager, UserMixin



# Initialize Flask App
app = Flask(__name__)
app.secret_key = "your_secret_key"  # Needed for session management
app.permanent_session_lifetime = timedelta(hours=1)  # Set session timeout

# Initialize Firebase Admin SDK (Only initialize if not already initialized)
if not firebase_admin._apps:
    cred = credentials.Certificate("service.json")  # Ensure correct path
    firebase_admin.initialize_app(cred, {"storageBucket": "creditscoreapp-1d5dc.appspot.com"})

db = firebase_admin.firestore.client()
bucket = storage.bucket()

# ----------------- Routes -----------------

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form.get('full_name')
        role = request.form.get('role')
        course = request.form.get('course')
        year = request.form.get('year')
        admission_year = request.form.get('admission_year')
        end_year = request.form.get('end_year')
        student_id = request.form.get('student_id')
        email_username = request.form.get('email_username').strip()
        password = request.form.get('password')
        
        email = email_username + "@example.com"  # Ensure a valid email domain

        # Check if student ID or email already exists
        existing_user = db.collection("users").where("student_id", "==", student_id).get()
        existing_email = db.collection("users").where("email", "==", email).get()

        if existing_user:
            flash('Student ID already exists!', 'danger')
            return redirect(url_for('register'))
        if existing_email:
            flash('Email already exists!', 'danger')
            return redirect(url_for('register'))

        try:
            user = auth.create_user(email=email, password=password)
            user_data = {
                "uid": user.uid,
                "full_name": full_name,
                "role": role,
                "course": course,
                "year": year,
                "admission_year": admission_year,
                "end_year": end_year,
                "student_id": student_id,
                "email": email,
                "credit_points": 0,
                "profile_pic": "https://storage.googleapis.com/creditscoreapp-1d5dc.appspot.com/profile_pics/default_profile.png",
                "attendance": 0,  # ✅ Default attendance value
                "grade": "None",  # ✅ Default grade value
                "participations": 0,  # ✅ Default participations
                "prizes": 0  # ✅ Default prizes won
            }
            db.collection("users").document(user.uid).set(user_data)

            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('login'))

        except Exception as e:
            flash(f"Error: {str(e)}", 'danger')
            return redirect(url_for('register'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')  # Render login page on GET request

    email = request.form.get('email')
    password = request.form.get('password')

    if not email or not password:
        return jsonify({"success": False, "error": "Email and password are required!"}), 400

    try:
        user = login_user(email, password)  # Authentication function

        if "error" in user:
            return jsonify({"success": False, "error": "Invalid email or password!"}), 401

        session["user_id"] = user["uid"]
        session["email"] = email
        session["idToken"] = user["idToken"]
        session.permanent = True  # Keep session active

        return jsonify({"success": True, "message": "Login successful!", "redirect": url_for('dashboard')})

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))


from flask import render_template, redirect, url_for, session
from firebase_config import db
from flask_login import login_required, current_user
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash("Please log in first!", "warning")
        return redirect(url_for('login'))

    user_id = session["user_id"]
    students_ref = db.collection('students')
    students = students_ref.stream()

    try:
        # Fetch user document
        user_doc = db.collection("users").document(user_id).get()

        if not user_doc.exists:
            flash("User not found!", "danger")
            return redirect(url_for('login'))

        user_data = user_doc.to_dict()
        user_data.setdefault("certificates", [])
        user_data.setdefault("profile_pic", None)

        # Handle profile picture
        if user_data["profile_pic"]:
            if user_data["profile_pic"].startswith("gs://"):
                file_path = user_data["profile_pic"].replace("gs://creditscoreapp-1d5dc.appspot.com/", "")
                user_data["profile_pic"] = f"https://storage.googleapis.com/creditscoreapp-1d5dc.appspot.com/{file_path}"
        else:
            user_data["profile_pic"] = url_for('static', filename='default_profile.png')

        # Fetch certificates array from user data
        certificates_raw = user_data.get('certificates', [])
        certificates_list = []

        for cert in certificates_raw:
            file_url = cert.get('file_url', '')
            file_name = file_url.split('/')[-1]  # ✅ Extract only file name
            certificates_list.append({
                'category': cert.get('category', ''),
                'file_name': file_name
            })


        # Prepare leaderboard
        leaderboard = []
        for student in students:
            student_data = student.to_dict()

            # Convert profile picture if exists
            student_profile_pic = student_data.get('profile_pic')
            if student_profile_pic and student_profile_pic.startswith("gs://"):
                student_file_path = student_profile_pic.replace("gs://creditscoreapp-1d5dc.appspot.com/", "")
                student_profile_pic = f"https://storage.googleapis.com/creditscoreapp-1d5dc.appspot.com/{student_file_path}"
            elif not student_profile_pic:
                student_profile_pic = url_for('static', filename='default_profile.png')

            leaderboard.append({
                'full_name': student_data.get('full_name'),
                'profile_pic': student_profile_pic,
                'course': student_data.get('course'),
                'year': student_data.get('year'),
                'credit_points': student_data.get('credit_points', 0)
            })

        # Sort leaderboard by credit points descending
        leaderboard.sort(key=lambda x: x['credit_points'], reverse=True)

        return render_template(
            'dashboard.html',
            leaderboard=leaderboard,
            current_user=user_data,
            certificates=certificates_list
        )

    except Exception as e:
        flash(f"Error loading dashboard: {str(e)}", "danger")
        return redirect(url_for('login'))

@app.route('/get_certificate_image/<image_name>')
def get_certificate_image(image_name):
    blob = bucket.blob(f"certificates/{image_name}")
    if not blob.exists():
        return send_file("static/default_certificate.png", mimetype='image/png')
    img_data = blob.download_as_bytes()
    return send_file(io.BytesIO(img_data), mimetype='image/jpeg')


@app.route('/get_profile_image/<image_name>')
def get_profile_image(image_name):
    blob = bucket.blob(f"profile_pics/{image_name}")  # Get the image blob
    img_data = blob.download_as_bytes()  # Download image as bytes

    if not blob.exists():  # Handle case where the image doesn't exist
        return send_file("static/default_profile.png", mimetype='image/png')

    img_data = blob.download_as_bytes()  # Download image as bytes

    return send_file(io.BytesIO(img_data), mimetype='image/jpeg')

@app.route('/check-session')
def check_session():
    return jsonify({"user": session.get("email", "No user in session")})

from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_login import login_required, current_user
import time

@app.route("/edit_profile", methods=["GET", "POST"])
def edit_profile():
    if "user_id" not in session:  # Check session instead of Flask-Login
        flash("Please log in first!", "warning")
        return redirect(url_for("login"))

    user_id = session["user_id"]  # Get user ID from session
    user_ref = db.collection("users").document(user_id)

    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()  # Get name safely
        profile_pic = request.files.get("profile_pic")  
        profile_url = None  

        if profile_pic:
            # Validate file extension correctly
            _, file_ext = os.path.splitext(profile_pic.filename)
            file_ext = file_ext.lower()

            if file_ext not in [".jpg", ".jpeg", ".png"]:
                flash("Invalid file type! Upload only JPG or PNG images.", "danger")
                return redirect(url_for("edit_profile"))

            # Upload profile picture to Firebase Storage
            blob = bucket.blob(f"profile_pics/{user_id}.jpg")
            blob.upload_from_file(profile_pic, content_type=profile_pic.content_type)

            # Get the correct public URL
            profile_url = f"https://storage.googleapis.com/{bucket.name}/{blob.name}"

        # Fetch existing user data
        user_doc = user_ref.get()
        if user_doc.exists:
            user_data = user_doc.to_dict()
            if not profile_url:  # If no new image, retain old one
                profile_url = user_data.get("profile_pic", url_for('static', filename='default_profile.jpg'))

        # Update Firestore document
        update_data = {"full_name": full_name}
        if profile_url:
            update_data["profile_pic"] = profile_url  

        user_ref.update(update_data)

        flash("Profile updated successfully!", "success")
        return redirect(url_for("dashboard"))

    # Fetch user data for pre-filling the form
    user_doc = user_ref.get()
    if user_doc.exists:
        user_data = user_doc.to_dict()
        profile_pic = user_data.get("profile_pic", url_for('static', filename='default_profile.png'))
        full_name = user_data.get("full_name", "")

    return render_template("edit_profile.html", full_name=full_name, profile_pic=profile_pic)

@app.route('/scan_qr')
def scan_qr():
    """Renders the QR scanning page."""
    if 'email' not in session:  # Corrected session check
        return redirect(url_for('login'))  # Ensure user is logged in
    return render_template('scan_qr.html')



import uuid

# Credit points mapping
CREDIT_POINTS = {
    "Sports": 200,
    "Academics": 300,
    "Cultural": 250
}

@app.route('/upload_certificate', methods=['GET', 'POST'])
def upload_certificate():
    if 'user_id' not in session:
        flash("Please log in to upload certificates!", "error")
        return redirect(url_for('login'))  # Redirect to login page

    user_id = session['user_id']
    db = firestore.client()
    user_ref = db.collection('users').document(user_id)  # Reference to the user's document

    if request.method == 'POST':
        file = request.files.get('certificate')
        category = request.form.get('category')

        if not file or not category:
            flash("Please select a file and category!", "error")
            return redirect(url_for('upload_certificate'))

        # Generate unique filename
        ext = os.path.splitext(file.filename)[1]
        file_name = f"{user_id}_{uuid.uuid4()}{ext}"

        # Upload to Firebase Storage
        bucket = storage.bucket()
        blob = bucket.blob(f"certificates/{file_name}")
        blob.upload_from_file(file, content_type=file.content_type)

        # Get file URL
        file_url = blob.public_url

        # Fetch user data from Firestore
        user_doc = user_ref.get()
        if user_doc.exists:
            user_data = user_doc.to_dict()
            certificates = user_data.get("certificates", [])  # Existing certificates
            current_points = user_data.get("credit_points", 0)  # Existing points
            current_participations = user_data.get("participations", 0)  # ✅ Existing participations
            current_prizes = user_data.get("prizes", 0)  # ✅ Existing prizes
        else:
            certificates = []
            current_points = 0
            current_participations = 0
            current_prizes = 0

        # Append the new certificate
        certificates.append({
            "category": category,
            "file_url": file_url
        })

        # Calculate new values
        added_points = CREDIT_POINTS.get(category, 0)  # Points for category
        new_credit_points = current_points + added_points
        new_participations = current_participations + 1  # ✅ Increment participation

        # Increment prizes only if category is "Sports"
        new_prizes = current_prizes
        if category == "Sports":
            new_prizes += 1  # ✅ Increment prize

        # Update Firestore user document
        user_ref.update({
            "certificates": certificates,
            "credit_points": new_credit_points,
            "participations": new_participations,
            "prizes": new_prizes
        })

        flash(f"Certificate uploaded successfully! You earned {added_points} points!", "success")
        return redirect(url_for('dashboard'))

    return render_template('upload_certificate.html')



@app.route('/get_leaderboard')
def get_leaderboard():
    users_ref = db.collection('users')
    users = users_ref.order_by('credit_points', direction=firestore.Query.DESCENDING).stream()

    leaderboard_data = []
    rank = 1
    for user in users:
        user_data = user.to_dict()
        
        # Ensure profile picture is only the filename
        profile_pic = user_data.get("profile_pic", "default_profile.png")

        leaderboard_data.append({
            "rank": rank,
            "full_name": user_data.get("full_name", "N/A"),
            "credit_points": user_data.get("credit_points", 0),
            "class": user_data.get("course", "N/A"),
            "year": user_data.get("year", "N/A"),
            "profile_pic": profile_pic  # 🔥 Store only filename, frontend will fetch from Firebase Storage
        })
        rank += 1

    return jsonify(leaderboard_data)





if __name__ == "__main__":
    app.run(debug=True)
