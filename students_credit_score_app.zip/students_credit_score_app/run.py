import secrets
print(secrets.token_hex(32))  # Generates a 64-character (32-byte) hex key
