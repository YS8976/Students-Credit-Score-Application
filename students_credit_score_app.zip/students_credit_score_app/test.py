import requests
from PIL import Image
from io import BytesIO

# Firebase Storage URL of the profile picture
image_url = "https://storage.googleapis.com/creditscoreapp-1d5dc.appspot.com/profile_pics/B4niKyCYUQPkFtNIPA7tSkqUG4C3.jpg"

try:
    # Fetch the image from Firebase Storage
    response = requests.get(image_url)
    
    # Check if the request was successful
    if response.status_code == 200:
        image = Image.open(BytesIO(response.content))  # Open image from bytes
        image.show()  # Display the image
    else:
        print(f"Error: Unable to fetch image. Status Code: {response.status_code}")
except Exception as e:
    print(f"Error: {e}")
