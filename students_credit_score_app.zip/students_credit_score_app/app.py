from flask import Flask
from flask_session import Session  # To manage sessions
from flask_login import LoginManager
from students_credit_app.routes import app as flask_app  # Import app from routes.py
import firebase_admin
from firebase_admin import credentials, storage, firestore

# Initialize Flask App
app = flask_app

# Enable sessions
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"  # Redirect to login page if user is not authenticated

# Prevent Firebase re-initialization
if not firebase_admin._apps:
    cred = credentials.Certificate("service.json")  # Ensure correct path
    firebase_admin.initialize_app(cred, {
        'storageBucket': 'creditscoreapp-1d5dc.appspot.com'
    })

# Now, get Firestore and Storage
db = firestore.client()
bucket = storage.bucket()


# Define the user loader function for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    user_ref = db.collection("users").document(user_id)
    user_doc = user_ref.get()
    
    if user_doc.exists:
        from flask_login import UserMixin
        user_data = user_doc.to_dict()

        class User(UserMixin):
            def __init__(self, user_id, full_name):
                self.id = user_id
                self.full_name = full_name

        return User(user_id, user_data.get("full_name", ""))
    
    return None

# Run the App
if __name__ == "__main__":
    app.run(debug=True)
