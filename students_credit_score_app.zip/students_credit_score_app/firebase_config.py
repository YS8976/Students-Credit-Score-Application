import pyrebase
import firebase_admin
from firebase_admin import credentials, firestore, storage  # Import storage

# Pyrebase Configuration (For Authentication)
firebase_config = {
    "apiKey": "AIzaSyC5E9rLx2yfA_wIpDBPsf60bTztaaVJHgw",
    "authDomain": "creditscoreapp-1d5dc.firebaseapp.com",
    "databaseURL": "https://creditscoreapp-1d5dc.firebaseio.com",
    "storageBucket": "creditscoreapp-1d5dc.appspot.com",  # Ensure this is correct
    "messagingSenderId": "1073791004936",
    "appId": "1:1073791004936:web:504301c7517f658fe57cbd",
    "measurementId": "YOUR_MEASUREMENT_ID"
}

# Initialize Pyrebase for Authentication
firebase = pyrebase.initialize_app(firebase_config)
auth = firebase.auth()

# Initialize Firebase Admin SDK for Firestore & Storage
if not firebase_admin._apps:  # Prevents duplicate initialization
    cred = credentials.Certificate("service.json")  # Ensure this file is correct
    firebase_admin.initialize_app(cred, {
        "storageBucket": "creditscoreapp-1d5dc.appspot.com"  # Explicitly specify storage bucket
    })

db = firestore.client()  # Firestore database reference
bucket = storage.bucket()  # Initialize Firebase Storage (Fixes your error)

# Authentication Functions
def login_user(email, password):
    """Logs in user using Firebase Authentication (Pyrebase)."""
    try:
        user = auth.sign_in_with_email_and_password(email, password)
        return {"uid": user['localId'], "email": email, "idToken": user['idToken']}
    except Exception as e:
        return {"error": str(e)}

def signup_user(email, password):
    """Creates a new user with email and password using Pyrebase."""
    try:
        user = auth.create_user_with_email_and_password(email, password)
        return {"uid": user['localId'], "email": email}
    except Exception as e:
        return {"error": str(e)}
